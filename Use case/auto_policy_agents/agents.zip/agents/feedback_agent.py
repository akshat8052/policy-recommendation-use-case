def feedback_agent(state):
    feedback = "User satisfied with recommendation."
    return {"feedback": feedback}
