def explainer_agent(state):
    print('No of policies',len(state.scored_policies))
    top_policy = state.scored_policies[0]  # Pydantic-style access
    user = state.user_profile

    # Generate explanation
    explanation = f"""
Top recommended policy: **{top_policy['Policy Name']}** by **{top_policy['Insurance Provider']}**

🧠 **Why this was recommended for you:**
- You requested **{user['Coverage Type']}**, and this policy matches it.
- Your state (**{user['License State']}**) is covered by this policy.
- Your vehicle is **{2025 - user['Vehicle Year']} years old**, within the policy's limit of {top_policy['Vehicle Age Limit (Years)']} years.
- The policy accepts drivers with up to {top_policy['Max Past Claims Allowed']} past claims — you have {user['Claims in Last 5 Years']}.
- Your clean violation record meets the policy’s 3-year clean history requirement.

💰 **Policy Features:**
- Collision Deductible: ${top_policy['Collision Deductible']}
- Liability Limits: {top_policy['Liability Limits']}
- Optional Coverage: {top_policy['Optional Coverages Included'] or 'None'}
- Premium: ${top_policy['Base Premium (Annual)']} / year
- Customer Rating: ⭐ {top_policy['Customer Rating (out of 5)']} / 5
- Support: {'24/7' if top_policy['24/7 Support'] else 'Business hours only'}

🏁 **LangGraph Match Score**: **{top_policy['score']}**
    """.strip()

    return {"explanation": explanation}
